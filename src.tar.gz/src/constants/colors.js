export default {
  BLACK:            '#000000',
  WHITE:            '#FFFFFF',
  ORANGE_LIGHT:     '#E3A177',
  ORANGE_DARK:      '#E67861',
  GREY_LIGHT:       '#848484',
  GREY_DARK:        '#909498'
}
