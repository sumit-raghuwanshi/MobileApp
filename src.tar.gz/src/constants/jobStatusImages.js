// export const prospect = require("../../img/jobStatus/prospect.png");
// export const approved = require("../../img/jobStatus/approved.png");
// export const completed = require("../../img/jobStatus/completed.png");
// export const invoiced = require("../../img/jobStatus/invoiced.png");
// export const closed = require("../../img/jobStatus/closed.png");
// export const lead = require("../../img/jobStatus/leads.png");

 
export const tradeType = {
    0:"Gutters",
    1:"HVAC",
    2:"Insulation",
    3:"Interior",
    4:"Painting",
    5:"Repair",
    6:"Roofing",
    7:"Siding",
    8:"Windows"
}

export const arrayJobStatus = {0:"Lead", 1:"Prospect" , 2:"Approved" , 3:"Completed" , 4:"Invoiced" , 5:"Closed"}
//export const arrayJobStatus = ["Lead", "Prospect" , "Approved" , "Completed" , "Invoiced" , "Closed"]