import { AsyncStorage } from 'react-native';
export default {
  appointments: [],
  user: null,
  jobs: [],
  leads: [],
  messages: [],
  tasks: [],
  templates: [],
  users: [],
  updated: false
};
